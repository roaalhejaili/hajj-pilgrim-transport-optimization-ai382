# Hajj Pilgrim Transportation Optimization

This project implements an optimization solution for the Hajj pilgrim transportation problem using Linear Programming (LP) and Integer Programming (IP) with Branch and Bound algorithm.

## Project Structure

- `main.py`: Contains the main problem formulation and execution
- `optimizer.py`: Implementation of optimization algorithms
- `data/`: Directory for input data (if needed)

## Requirements

- Python 3.7+
- NumPy
- Matplotlib

## How to Run

1. Install the required packages:
```bash
pip install numpy matplotlib
```

2. Run the main script:
```bash
python main.py
```

## Features

- Linear Programming solver using Vertex Enumeration
- Integer Programming solver using Branch and Bound
- Constraint intersection finder
- 2D problem visualization (when applicable)

## Problem Description

The implementation solves a simplified version of the Hajj transportation problem with:
- 2 ports (p1, p2) with 60 and 40 pilgrims respectively
- 2 hotels (h1, h2) with capacity 80 and 40 respectively
- Bus capacity: 50 pilgrims per bus
- Transport costs:
  - p1->h1: 100 SAR
  - p1->h2: 80 SAR
  - p2->h1: 90 SAR
  - p2->h2: 120 SAR